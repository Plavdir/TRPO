﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class TNumber 
    {
        //Число
        double number;
        //Основание системы счисления
        int p;

        //Конвертер
        TConverter conv;
        
        //Конструктор
        public TNumber(double num, int bas)
        {
            //Сист. сч.
            p = bas;
            //Число
            number = num;
            //Конвертер
            conv = new TConverter(bas);
        }

        //Сложить
        public TNumber Summ(TNumber num)
        {
            TNumber res = new TNumber(number, p);

            res.number = number + num.number;

            return res;
        }

        //Умножить
        public TNumber Mult(TNumber num)
        {
            TNumber res = new TNumber(number, p);

            res.number = number * num.number;

            return res;
        }

        //Вычесть
        public TNumber Sub(TNumber num)
        {
            TNumber res = new TNumber(number, p);

            res.number = number - num.number;

            return res;
        }

        //Делить
        public TNumber Div(TNumber num)
        {
            TNumber res = new TNumber(number, p);

            res.number = number / num.number;

            return res;
        }

        //Обратить
        public TNumber Pay()
        {
            TNumber res = new TNumber(number, p);

            res.number = 1 / number;

            return res;
        }

        //Квадрат
        public TNumber Sqr()
        {
            TNumber res = new TNumber(number, p);

            res.number = Math.Pow(number, 2);

            return res;
        }

        //Копия числа
        public TNumber Copy()
        {
            TNumber res = new TNumber(number, p);
            return res;
        }

        //Установить и получить число числом
        public double NumberDouble
        {
            set { this.number = value; }
            get { return this.number; }
        }

        //Установить и получить число строкой
        public string NumberString
        {
            set
            {
                conv.SetP = p;
                if (p != 10)
                    number = conv.P_To_10(value);
                else
                {
                    value = value.Replace('.', ',');
                    if (value == "")
                        value = "0";
                    number = conv.P_To_10(value);
                    //number = Convert.ToDouble(value);
                }
            }
            get
            {
                conv.SetP = p;
                if (p != 10)
                    return conv.P10_To_P(number);
                else
                    return Convert.ToString(number);
            }
        }

        //Установить и получить основание строкой
        public string PString
        {
            set { this.p = Convert.ToInt32(value); }
            get { return Convert.ToString(p); }
        }

        //Установить и получить основание числом
        public int PInt
        {
            set { this.p = value; }
            get { return p; }
        }
    }
}
