﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        //Массив кнопок
        private Button[] btns = new Button[16];
        //Класс контроллер
        private TCtrl ctrl = new TCtrl();
        //Строка для вывода
        private string numb;
        //Строка для вывода
        private string numb2;
        //Строка для знака
        private string sign;

        private void Form1_Load(object sender, EventArgs e)
        {
            button22.ForeColor = Color.FromArgb(200, 0, 0);
            button23.ForeColor = Color.FromArgb(200, 0, 0);
            button24.ForeColor = Color.FromArgb(200, 0, 0);
            button1.ForeColor = Color.FromArgb(0, 102, 204);
            button2.ForeColor = Color.FromArgb(0, 102, 204);
            button3.ForeColor = Color.FromArgb(0, 102, 204);
            button4.ForeColor = Color.FromArgb(0, 102, 204);

            //Заносим все кнопки, отвечающий за числа в массив
            btns[0] = button5;
            btns[1] = button7;
            btns[2] = button8;
            btns[3] = button9;
            btns[4] = button10;
            btns[5] = button11;
            btns[6] = button12;
            btns[7] = button13;
            btns[8] = button14;
            btns[9] = button15;
            btns[10] = button16;
            btns[11] = button17;
            btns[12] = button18;
            btns[13] = button19;
            btns[14] = button20;
            btns[15] = button21;

            //Начальное значение для сист. сч. - это 10 сс
            comboBox1.SelectedIndex = 8;

            //Очищаем хранилище истории и памяти
            listBox1.Items.Clear();
            listBox2.Items.Clear();

            //Очистим буфер обмена
            Clipboard.Clear();

            //Скроем кнопку очистки истории
            button33.Visible = false;

            //Скроем кнопки комплексной части
            button34.Visible = false;
            button35.Visible = false;
            ctrl.TypeCalculator = 1;
            button30.Focus();
        }

        //Включение кнопок систем счислений
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Получаем индекс выбранной сс
            int index = comboBox1.SelectedIndex;

            //Все, что после выключаем
            for (int i = index; i < 16; i++)
                btns[i].Enabled = false;
            //Все, что до включаем
            for (int i = 0; i < index + 2; i++)
                btns[i].Enabled = true;

            //При изменении очищаем экран
            textBox1.Clear();
            //Очищаем и строку
            numb = ctrl.editor.Clear();
            //Чтобы снять выделение с ComboBox, переводим фокус на другой любой элемент
            button30.Focus();

            //Начальное значение для textBox
            textBox1.Text = "0.";

            //Записываем номер сс в классы для конвертации
            ctrl.processor.LeftOp.PInt = index + 2;
            ctrl.processor.RightOp.PInt = index + 2;
        }

        //Обработчик всех комманд
        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            //Получаем Тэг кнопки
            int comm = Convert.ToInt32(((sender as Button).Tag));
            int state = ctrl.editor.State;
            if (numb != "" && sign == null)
                numb2 = numb;
            switch (ctrl.TypeCalculator)
            {
                case (1):
                    numb = ctrl.DoCommand(comm);
                    switch (ctrl.editor.State)
                    {
                        case (0):
                            textBox1.Text = numb;
                            break;
                        case (1):
                            numb2 = ctrl.processor.LeftOp.NumberString;
                            textBox1.Text = numb2 + "\r\n" + sign + "\r\n" + numb;
                            break;
                        case (2):
                            numb = ctrl.processor.LeftOp.NumberString;
                            textBox1.Text = numb + "\r\n" + sign;
                            break;
                        case (3):
                            textBox1.Text = numb;
                            break;
                    }
                    if (comm >= 23 && comm <= 24)
                    {
                        if (ctrl.memory.Number.PInt < 10)
                            listBox2.Items.Add(ctrl.memory.Number.NumberDouble + " (" + ctrl.memory.Number.PInt + ") ");
                        else
                            listBox2.Items.Add(ctrl.memory.Number.NumberString + " (" + ctrl.memory.Number.PInt + ") ");
                        listBox2.SelectedIndex = listBox2.Items.Count - 1;
                        listBox2.SelectedIndex = -1;
                    }
                    break;
                case (2):
                    numb = ctrl.DoCommandFract(comm);
                    switch (ctrl.Feditor.State)
                    {
                        case (0):
                            textBox1.Text = numb;
                            break;
                        case (1):
                            numb2 = ctrl.Fprocessor.LeftOp.NumberString;
                            textBox1.Text = numb2 + "\r\n" + sign + "\r\n" + numb;
                            break;
                        case (2):
                            numb = ctrl.Fprocessor.LeftOp.NumberString;
                            textBox1.Text = numb + "\r\n" + sign;
                            break;
                        case (3):
                            textBox1.Text = numb;
                            break;
                    }
                    if (comm >= 23 && comm <= 24)
                    {
                        listBox2.Items.Add(ctrl.Fmemory.Number.NumberString);
                        listBox2.SelectedIndex = listBox2.Items.Count - 1;
                        listBox2.SelectedIndex = -1;
                    }
                    break;
                case (3):
                    numb = ctrl.DoCommandComplex(comm);
                    switch (ctrl.Ceditor.State)
                    {
                        case (0):
                            textBox1.Text = numb;
                            break;
                        case (1):
                            numb2 = ctrl.Cprocessor.LeftOp.NumberString;
                            textBox1.Text = numb2 + "\r\n" + sign + "\r\n" + numb;
                            break;
                        case (2):
                            numb = ctrl.Cprocessor.LeftOp.NumberString;
                            textBox1.Text = numb + "\r\n" + sign;
                            break;
                        case (3):
                            textBox1.Text = numb;
                            break;
                    }
                    if (comm >= 23 && comm <= 24)
                    {
                        if (ctrl.Cmemory.Number.PInt < 10)
                            listBox2.Items.Add(ctrl.Cmemory.Number.NumberDouble);
                        else
                            listBox2.Items.Add(ctrl.Cmemory.Number.NumberString);
                        listBox2.SelectedIndex = listBox2.Items.Count - 1;
                        listBox2.SelectedIndex = -1;
                    }
                    break;
            }


            if (sign == "=")
            {
                if (numb == "")
                {
                    textBox1.Text = numb2;
                    numb = numb2;
                }
                else
                {
                    textBox1.Text = numb;
                    numb2 = numb;
                }
                var nan = textBox1.Text.Split('/');
                if (nan.Count() > 1 && nan[1] == "0")
                {
                    textBox1.Text = "NaN";
                    return;
                }
            }


            if (comm >= 25 && comm <= 28 && state == 0)
            {
                ctrl.DoCommandFract(99);
                button34.BackColor = Color.FromName("ButtonShadow");
                button35.BackColor = Color.FromName("ActiveCaption");
            }
            if (comm == 40 || comm == 30 || comm == 31 || (comm >= 25 && comm <= 28 && state != 0))
            {

                if (numb != null && !numb.Equals("Деление на ноль невозможно!"))
                {
                    if (numb != "")
                    {
                        string temp3 = "(" + comboBox1.SelectedItem.ToString() + ") " + ctrl.history.GetRecordByIndex(ctrl.history.size - 1);
                        listBox1.Items.Add(temp3);
                        if (button33.Visible == false) button33.Visible = true;
                    }
                    listBox1.SelectedIndex = listBox1.Items.Count - 1;
                    listBox1.SelectedIndex = -1;
                }

                var nan = textBox1.Text.Split('/');
                if (nan.Length > 1 && nan[1] == "0")
                {
                    textBox1.Text = "NaN";
                    return;
                }
            }

            if (comm == 21)
            {
                listBox2.Items.Clear();
            }


            if (comm == 18 || comm == 20)
            {
                textBox1.Text = "";
                sign = null;
                numb2 = null;
            }
            button30.Focus();
            if (textBox1.Text == "")
            {
                if (ctrl.TypeCalculator == 3)
                    textBox1.Text = "0.+i0.";
                else if (ctrl.TypeCalculator == 2)
                    textBox1.Text = "0/1";
                else
                    textBox1.Text = "0.";
            }

        }

        //Обработка нажатий клавиш
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int index = comboBox1.SelectedIndex;
            if (ctrl.editor.number.Length < ctrl.editor.MaxLength)
                switch (e.KeyCode)
                {
                    case Keys.NumPad0:
                    case Keys.D0: button5_Click(button5, null); break;
                    case Keys.NumPad1:
                    case Keys.D1: button7.PerformClick();/* button5_Click(button7, null);*/ break;
                    case Keys.NumPad2:
                    case Keys.D2: if (index >= 1) button5_Click(button8, null); break;
                    case Keys.NumPad3:
                    case Keys.D3: if (index >= 2) button5_Click(button9, null); break;
                    case Keys.NumPad4:
                    case Keys.D4: if (index >= 3) button5_Click(button10, null); break;
                    case Keys.NumPad5:
                    case Keys.D5: if (index >= 4) button5_Click(button11, null); break;
                    case Keys.NumPad6:
                    case Keys.D6: if (index >= 5) button5_Click(button12, null); break;
                    case Keys.NumPad7:
                    case Keys.D7: if (index >= 6) button5_Click(button13, null); break;
                    case Keys.NumPad8:
                    case Keys.D8: if (index >= 7) button5_Click(button14, null); break;
                    case Keys.NumPad9:
                    case Keys.D9: if (index >= 8) button5_Click(button15, null); break;
                    case Keys.OemPeriod:
                    case Keys.Decimal:
                    case Keys.Oemcomma: button5_Click(button6, null); break;
                    case Keys.A: if (index >= 9) button5_Click(button16, null); break;
                    case Keys.B: if (index >= 10) button5_Click(button17, null); break;
                    case Keys.C: if (index >= 11) button5_Click(button18, null); break;
                    case Keys.D: if (index >= 12) button5_Click(button19, null); break;
                    case Keys.E: if (index >= 13) button5_Click(button20, null); break;
                    case Keys.F: if (index >= 14) button5_Click(button21, null); break;
                }
            switch (e.KeyCode)
            {
                case Keys.Add:
                case Keys.Oemplus: //ctrl.processor.Operation = 1; 
                                   //ctrl.processor.LeftOp.NumberString = ctrl.editor.number;
                                   //ctrl.processor.LeftOp.PInt = comboBox1.SelectedIndex + 2;
                                   //ctrl.editor.Clear();
                    sign = "+";
                    button25.PerformClick();
                    //textBox1.Clear();
                    break;
                case Keys.Subtract:
                case Keys.OemMinus: //ctrl.processor.Operation = 2; 
                                    //ctrl.processor.LeftOp.NumberString = ctrl.editor.number;
                                    //ctrl.processor.LeftOp.PInt = comboBox1.SelectedIndex + 2;
                                    //ctrl.editor.Clear();
                                    //textBox1.Clear(); 
                    sign = "-";
                    button26.PerformClick();
                    break;
                case Keys.Multiply: //ctrl.processor.Operation = 3; 
                                    //ctrl.processor.LeftOp.NumberString = ctrl.editor.number;
                                    //ctrl.processor.LeftOp.PInt = comboBox1.SelectedIndex + 2;
                                    //ctrl.editor.Clear();
                                    //textBox1.Clear(); 
                    sign = "*";
                    button27.PerformClick();
                    break;
                case Keys.Divide:   //ctrl.processor.Operation = 4;
                                    //ctrl.processor.LeftOp.NumberString = ctrl.editor.number;
                                    //ctrl.processor.LeftOp.PInt = comboBox1.SelectedIndex + 2;
                                    //ctrl.editor.Clear();
                                    //textBox1.Clear(); 
                    sign = "/";
                    button28.PerformClick();
                    break;
                case Keys.Enter:    //ctrl.processor.RightOp.NumberString = ctrl.editor.number;
                                    //numb = ctrl.ExecOperation(ctrl.editor.number);
                                    //textBox1.Clear();
                                    //textBox1.Text = numb;
                                    //listBox1.Items.Add(ctrl.history.GetRecordByIndex(ctrl.history.Size - 1));
                    sign = "=";
                    button30.PerformClick();
                    break;
                default: break;
            }

            switch (e.KeyCode)
            {
                case Keys.Delete: sign = "="; button5_Click(button24, null); break;
                case Keys.Escape: Close(); break;
                case Keys.Back: button5_Click(button22, null); break;
            }
            button30.Focus();
        }

        private void разработчикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ctrl.reference._devel, "Разработчики");
        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetData(DataFormats.StringFormat, textBox1.Text);
        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = (string)Clipboard.GetData(DataFormats.StringFormat);
            ctrl.editor.number = textBox1.Text;
        }

        private void button33_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            ctrl.history.ClearHistory();
            button33.Visible = false;
        }

        private void button25_Click(object sender, EventArgs e)
        {
            sign = "+";
            button5_Click(button25, null);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            sign = "-";
            button5_Click(button26, null);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            sign = "*";
            button5_Click(button27, null);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            sign = "/";
            button5_Click(button28, null);
        }

        private void button30_Click(object sender, EventArgs e)
        {
            sign = "=";
            button5_Click(button30, null);
        }

        private void журналToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!tabControl1.Visible)
            {
                this.Height = 670;
                tabControl1.Visible = true;
            }
            else
            {
                tabControl1.Visible = false;
                this.Height = 440;
            }
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ctrl.reference._about, "О программе");
        }

        private void ричныйКалькуляторToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Начальное значение для сист. сч. - это 10 сс
            comboBox1.SelectedIndex = 8;
            comboBox1.Visible = true;
            label1.Visible = true;
            //Делаем невидимыми кнопки комплексных чисел
            button34.Visible = false;
            button35.Visible = false;
            button6.Enabled = true;
            //При изменении очищаем экран
            textBox1.Clear();
            //Очищаем и строку
            numb = ctrl.editor.Clear();
            //Чтобы снять выделение с ComboBox, переводим фокус на другой любой элемент
            button5.Focus();
            button31.Enabled = true;
            //Начальное значение для textBox
            textBox1.Text = "0.";

            //Записываем номер сс в классы для конвертации
            ctrl.processor.LeftOp.PInt = 10;
            ctrl.processor.RightOp.PInt = 10;
            ctrl.TypeCalculator = 1;
        }

        private void простыхДробейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Начальное значение для сист. сч. - это 10 сс
            comboBox1.SelectedIndex = 8;
            comboBox1.Visible = false;
            label1.Visible = false;
            //Делаем невидимыми кнопки комплексных чисел
            button34.Text = "Чис";
            button35.Text = "Знам";
            button34.Visible = true;
            button35.Visible = true;
            button6.Enabled = false;
            //При изменении очищаем экран
            textBox1.Clear();
            //Очищаем и строку
            numb = ctrl.Feditor.Clear();
            //Чтобы снять выделение с ComboBox, переводим фокус на другой любой элемент
            button5.Focus();
            button31.Enabled = true;
            //Начальное значение для textBox
            textBox1.Text = "0/1";

            //Записываем номер сс в классы для конвертации
            ctrl.Fprocessor.LeftOp.PInt = 10;
            ctrl.Fprocessor.RightOp.PInt = 10;
            ctrl.TypeCalculator = 2;
        }

        private void комплексныхЧиселToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Начальное значение для сист. сч. - это 10 сс
            comboBox1.SelectedIndex = 8;
            comboBox1.Visible = false;
            label1.Visible = false;
            //При изменении очищаем экран
            textBox1.Clear();
            //Очищаем и строку
            numb = ctrl.Ceditor.Clear();
            button6.Enabled = true;
            //Чтобы снять выделение с ComboBox, переводим фокус на другой любой элемент
            button5.Focus();
            //button31.Enabled = false;
            //Начальное значение для textBox
            textBox1.Text = "0.+0.i";

            //Записываем номер сс в классы для конвертации
            ctrl.Cprocessor.LeftOp.PInt = 10;
            ctrl.Cprocessor.RightOp.PInt = 10;

            //Делаем видимыми кнопки комплексных чисел
            button34.Text = "Re";
            button35.Text = "Im";
            button34.Visible = true;
            button35.Visible = true;
            ctrl.TypeCalculator = 3;
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void button34_MouseClick(object sender, MouseEventArgs e)
        {
            button34.BackColor = Color.FromName("ButtonShadow");
            button34.FlatAppearance.BorderColor = Color.FromName("ButtonShadow");
            button35.BackColor = Color.FromName("Azure");
            button35.FlatAppearance.BorderColor = Color.FromName("Azure");
            button35.Enabled = true;
            button34.Enabled = false;
        }

        private void button35_MouseClick(object sender, MouseEventArgs e)
        {
            button35.BackColor = Color.FromName("ButtonShadow");
            button35.FlatAppearance.BorderColor = Color.FromName("ButtonShadow");
            button34.BackColor = Color.FromName("Azure");
            button34.FlatAppearance.BorderColor = Color.FromName("Azure");
            button34.Enabled = true;
            button35.Enabled = false;
        }
    }
}
