﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class TReference
    {
        public string _about = "Калькулятор предназначен для работы с числами в системах счисления от 2 до 16";
        public string _devel = "Разработчики:\nОрлов М.В.\nШибалова Ю.В.\n";

    }
}
