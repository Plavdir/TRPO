﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Converter_p1_p2
{
    public partial class history : Form
    {
        public history()
        {
            InitializeComponent();
        }
    }
}
