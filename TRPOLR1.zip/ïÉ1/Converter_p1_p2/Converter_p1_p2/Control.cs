﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Converter_p1_p2
{
    class Control_
    {
            //объект редактор
            public Editor ed = new Editor();

            //Основание системы сч. исходного числа. 
            const int pin = 10;

            //Основание системы сч. результата. 
            const int pout = 10;

            //Число разрядов в дробной части результата. 
            const int accuracy = 10;

            public History his = new History();

            public enum State { Редактирование, Преобразовано }

            //Свойство для чтения и записи состояние Конвертера.
            public State St { get; set; }

            //Конструктор.
            public Control_()
            {
                St = State.Редактирование;
                Pin = pin;
                Pout = pout;
            }

            //Свойство для чтения и записи основание системы сч. р1.
            public int Pin { get; set; }

            //Свойство для чтения и записи основание системы сч. р2.
            public int Pout { get; set; }

            //Выполнить команду конвертера.
            public string DoCmnd(int j)
            {
                if (j == 19)
                {
                    double r = converter_P_10.dval(ed.Number, (Int16)Pin);
                    string res = converter_10_P.Do(r, (Int32)Pout, acc());
                    St = State.Преобразовано;
                    his.AddRecord(Pin, Pout, ed.Number, res);
                    return res;
                }
                else
                {
                    St = State.Редактирование;
                    return ed.DoEdit(j);
                }

            }
        //Точность представления результата.
        private int acc()
        {
            return (int)Math.Round(accuracy * Math.Log(Pin) / Math.Log(Pout) + 0.5);
        }
    }
}
