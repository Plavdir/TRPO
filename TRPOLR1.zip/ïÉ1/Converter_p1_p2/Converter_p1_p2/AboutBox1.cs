﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace Converter_p1_p2
{
    public partial class AboutBox1 : Form
    {
        public AboutBox1()
        {
            InitializeComponent();
            this.Text = "О программе";
            label1.Text = "Программа-конвертер, преобразующая числа";
            label6.Text = "из одной с.сч.в другую";
            label2.Text = "Авторы:";
            label3.Text = "Орлов Михаил";
            label4.Text = "Шибалова Юлия";
            label5.Text = "Copyright © 2019";
        }
    }
}
