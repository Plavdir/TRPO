﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trpo1
{
    class converter_P_10
    {
        //Преобразовать цифру в число.
        static double char_To_num(char ch)
        {
            return (ch - 'A') + 10;
        }

        //Преобразовать строку в число
        private static double convert(string P_num, int P, double weight)
        {
            double result = 0, k = 0;

            for (int i = 0; i < P_num.Length; i++)
            {
                if (P_num[i] >= 'A' && P_num[i] < 'G')
                    k = char_To_num(P_num[i]);
                else
                    k = P_num[i] - '0';

                result += k * weight;
                weight /= P;
            }

            return result;
        }
        //Преобразовать из с.сч. с основанием р 
        //в с.сч. с основанием 10.
        public static double dval(string P_num, int P)
        {
            int j = 0;
            bool f = true;
            int i;
            for (i = 0; i < P_num.Length && f; i++)
                if (P_num[i] == '.')
                {
                    j = i;
                    f = false;
                }
                
            string no_point = string.Empty;
            if (j != 0)
            {
                no_point = P_num.Remove(j, 1);
                i -= 2;
            }
            else
            {
                no_point = P_num;
                i -= 1;
            }
            
            return convert(no_point, P, Math.Pow(P, i));
        }

    }
}
