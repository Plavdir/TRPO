﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trpo1
{
    class Editor
    {
        //Поле для хранения редактируемого числа.
        string number = "";
        //Разделитель целой и дробной частей.
        const string delim = ".";
        //Ноль.
        const string zero = "0";
        //Свойствое для чтения редактируемого числа.
        public string Number
        {
            get { return number; }
        }
        //Добавить цифру.
        public string AddDigit(int n)
        {
            if (n >= 0 && n <= 9)
                number += n.ToString();
            else
            {
                number += (char)(n % 10 + 'A');
            }
            return number;

        }
        //Точность представления результата.
        public string Acc()
        {
            // можно ввести не более 10 цифр
            if (number.Length > 10)
                number = number.Remove(number.Length - 1);
            return number;
        }
        //Добавить ноль.
        public string AddZero()
        {
            if (number != "0")
                return number += zero;
            else
                return number;
        }
        //Добавить разделитель.
        public string AddDelim()
        {
            if (number == "")
                number = "0";

            for (int i = 0; i < number.Length; i++)
                if (number[i] == '.')
                    return number;

            return number += delim;
        }
        //Удалить символ справа.
        public string Bs()
        {
            if (number != "")
                return number = number.Remove(number.Length - 1, 1);
            return number;
        }
        //Очистить редактируемое число.
        public string Clear()
        {
            return number = string.Empty;
        }
        //Выполнить команду редактирования.
        public string DoEdit(int j)
        {
            if (number == "0")
                number = "";

            if ( j < 16 && j > 0)
            { 
                number = AddDigit(j);
                number = Acc();
                return number;
            }
            else
            {
                if (j == 0)
                    number = AddZero();
                if (j == 16)
                    number = AddDelim();
                if (j == 17)
                    number = Bs();
                if (j == 18)
                    number = Clear();
                number = Acc();
                //return number;
            }
            return number;
        }
    }
}
