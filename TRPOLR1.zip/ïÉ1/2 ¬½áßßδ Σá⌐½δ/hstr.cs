﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trpo1
{
    public struct Record
    {
        int p1;
        int p2;
        string number1;
        string number2;

        public Record(int p1, int p2, string n1, string n2)
        {
            this.p1 = p1;
            this.p2 = p2;
            this.number1 = n1;
            this.number2 = n2;
        }
        public override string ToString()
        {
            string s = "Переведено число " + number1 + " из системы счисления с основанием " + p1.ToString();
            s += " в систему счисления с основанием " + p2.ToString();
            s += ".\n Результат : " + number2 + '\n';
            return s;
        }
    }
    public class History
    {
        List<Record> L;

        public Record this[int i]
        {
            get { return L[i]; }
        }
        public void AddRecord(int p1, int p2, string n1, string n2)
        {
            Record r = new Record(p1, p2, n1, n2);
            L.Add(r);
        }
        public void Clear()
        {
            L.Clear();
        }
        public int Count()
        {
            return L.Count;
        }
        public History()
        {
            L = new List<Record>();
        }
    }

}
