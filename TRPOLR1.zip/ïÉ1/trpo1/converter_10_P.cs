﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trpo1
{
    
    class converter_10_P
    {
        private const int ASCII_TABLE_SHIFT = 55;

        //Преобразовать целое в символ.
        public static char int_to_Char(int n)
        {
            return (char)(n % 10 + 'A');
        }

        //Преобразовать десятичное целое в с.сч. с основанием р.
        public static string int_to_P(int n, int p)
        {
            int k = n;
            // остаток и частное
            int remainder = 0, quotient = 1;
            string result = string.Empty;
            char s = '0';
            while (quotient != 0)
            {
                quotient = k / p;
                //quotient = k / n;
                remainder = k - p * quotient;
                if (remainder >= 10)
                    s = int_to_Char(remainder);
                else
                    s = (char)('0' + remainder);

                result += s;
                s = '0';
                k = quotient;
            }

            string output = new string(result.ToCharArray().Reverse().ToArray());
            return output;
        }
        //Преобразовать десятичную дробь в с.сч. с основанием р.
        public static string flt_to_P(double n, int p, int c)
        {
            // дробь
            double fraction = 1;
            int i = 0, k;
            k = (int)Math.Floor(n); // целая часть
            fraction = n - k; // дробная часть
            string result = string.Empty, s = string.Empty;

            while (fraction != 0 && i < c)
            {
                i++;
                n = fraction * p;
                k = (int)Math.Floor(n); // целая часть

                if (k >= 10)
                    s += int_to_Char(k);
                else
                    s = Convert.ToString(k);
                result += s;
                s = string.Empty;
                fraction = n - k; // дробная часть

            }
            return result;
        }

        //Преобразовать десятичное 
        //действительное число в с.сч. с осн. р.
        public static string Do(double n, int p, int c)
        {
            int num;
            double fraction;

            num = (int)Math.Floor(n);
            fraction = n - num;
            string result = string.Empty;
            if (num != 0)
                result += int_to_P(num, p);
            else
                result += '0';
            string s = flt_to_P(fraction, p, c);

            if (s.Length != 0)
            {
                result += ".";
                result += s;
            }

            return result;

        }
    }

}

