﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trpo1
{
    class Editor
    {
        //Поле для хранения редактируемого числа.
        string number = "";
        //Разделитель целой и дробной частей.
        const string delim = ".";
        //Ноль.
        const string zero = "0";
        //Свойствое для чтения редактируемого числа.
        public string Number
        {
            get { return number; }
        }
        //Добавить цифру.
        public string AddDigit(int n)
        {
            if (n >= 0 && n <= 9)
                number += n.ToString();
            else
            {
                number += (char)(n % 10 + 'A');
            }
            return number;

        }
        //Точность представления результата.
        public int Acc()
        {
            return 10;
        }
        //Добавить ноль.
        public string AddZero()
        {
            if (number != "0")
                return number += zero;
            else
                return number;
        }
        //Добавить разделитель.
        public string AddDelim()
        {
            if (number == "")
                number = "0";
            return number += delim;
        }
        //Удалить символ справа.
        public string Bs()
        {
            if (number != "")
                return number = number.Remove(number.Length - 1, 1);
            return number;
        }
        //Очистить редактируемое число.
        public string Clear()
        {
            return number = string.Empty;
        }
        //Выполнить команду редактирования.
        public string DoEdit(int j)
        {
            if (number == "0")
                number = "";
            if ( j < 16 && j > 0)
            {
                return AddDigit(j);
            }
            else
            {
                if (j == 0)
                    return AddZero();
                if (j == 16)
                    return AddDelim();
                if (j == 17)
                    return Bs();
                if (j == 18)
                    return Clear();
                if (j == 19)
                {

                }
            }
            return number;

        }

    }
}
