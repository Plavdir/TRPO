﻿using System;
using System.IO;
using System.Windows.Forms;

/* Rewritten 22.05 - 23.05 by Str1ker
Known issues: 
 * [TEST] trackbar is not comfortable while working with fractional values
 * supply 21*=* as 21*21* not as 21*0*
 * infinity as a string
 * [TEST] exponential form causes exceptions after backspace
 * [TEST] ^2 on hexadecimal, binary overflow if 0<x<1
 * [TEST] precision loss somewhere (?!)
 * [TEST] 1/0.01 = 1 ????
 * [TEST] putting zeros like 0,0001 with non-decimal basis is invisible
 * add: show memory status (has value or not)
 * add: hover hint
 * 7 - MS - 8 - MR - press and do everything fails
 */

namespace proj2_tds_self {
    /// <summary>
    /// Главный класс программы.
    /// </summary>
    static class Program {
        /// <summary>
        /// Ссылка на форму истории.
        /// </summary>
        private static FormHistory _historyForm;

        /// <summary>
        /// Публично доступная ссылка на форму истории.
        /// </summary>
        public static FormHistory HistoryForm {
            get { return _historyForm ?? (_historyForm = new FormHistory()); }
        }

        public static string HistoryFile { get { return "history.txt"; } }

        private const string LogfilePath = "R:\\logfile.log";
        private static FileStream _logfile;
        public static StreamWriter Log;

        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        private static void Main() {
#if DEBUG
            try {
                _logfile = File.Open(LogfilePath, FileMode.Create,
                    FileAccess.Write, FileShare.Read // these flags should NOT be set via OR!!
                );
                Log = new StreamWriter(_logfile, System.Text.Encoding.UTF8) { AutoFlush = true };
                Log.WriteLine("=== Program start ===");
            }
            catch (Exception e) {
                MessageBox.Show("Не удалось создать файл '" + LogfilePath + "':\n" + e.Message +
                    "\n\nПриложение будет закрыто.",
                    "Ошибка во время загрузки", MessageBoxButtons.OK);
                Application.Exit();
            }
#endif
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormMain());
        }
    }
}