﻿using System;
using System.Globalization;

namespace proj2_tds_self {
    /// <summary>
    /// Класс, представляющий объекты числа в p-ичной системе счисления.
    /// </summary>
    public class PNumber {
        /// <summary>
        /// Основание системы счисления, используемой по умолчанию.
        /// </summary>
        public const int DecimalBasis = 10;
        /// <summary>
        /// Минимальное поддерживаемое основание системы счисления.
        /// </summary>
        public const int MinBasis = 2;
        /// <summary>
        /// Максимальное поддерживаемое основание системы счисления.
        /// </summary>
        public const int MaxBasis = 16;
        /// <summary>
        /// Строка, являющаяся разделителем целой и дробной части.
        /// </summary>
        public static readonly string DecimalPoint = ",";

        private static NumberStyles _style = NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint;
        private static NumberFormatInfo _format = new NumberFormatInfo() {
            NumberDecimalSeparator = DecimalPoint,
            PositiveInfinitySymbol = "бесконечность",
            NegativeInfinitySymbol = "-бесконечность"
        };

        // ReSharper disable once InconsistentNaming
        private static readonly P1ToDecimal CP10 = new P1ToDecimal();
        private static readonly DecimalToP1 C10P = new DecimalToP1();
        
        /// <summary>
        /// Система счисления, в которой записана строка _value.
        /// </summary>
        private byte _basis;

        /// <summary>
        /// Внутреннее представление числа. Используем строки, т.к. плохо подходят и UInt64 и double.
        /// </summary>
        private string _value;

        /// <summary>
        /// Создаёт новое p-ичное число.
        /// </summary>
        /// <param name="value">Строка, содержащая число.</param>
        /// <param name="basis">Основание системы, в которой записано число.</param>
        public PNumber(string value, byte basis = DecimalBasis) {
            if (basis < MinBasis || basis > MaxBasis) throw new OperationCanceledException();
            _basis = basis;
            _value = Parse(value, basis) ? value : string.Empty;
            //if(_value == "0") _value = String.Empty;
        }

        /// <summary>
        /// Создаёт новое p-ичное число.
        /// </summary>
        /// <param name="value">Десятичное число с плавающей запятой.</param>
        /// <param name="setBasis">Основание системы, в которую осуществить конвертацию.</param>
        public PNumber(double value, byte setBasis = DecimalBasis) {
            _value = DoConversion(Converter.ToString(value), DecimalBasis, setBasis);
            if (_value == "0") _value = String.Empty;
            _basis = setBasis;
        }

        /// <summary>
        /// Создаёт новое p-ичное число с нулевым значением.
        /// </summary>
        /// <param name="basis">Основание системы для дальнейшей работы с числом.</param>
        public PNumber(byte basis = DecimalBasis) {
            _value = string.Empty;
            _basis = basis;
        }

        /// <summary>
        /// Создаёт копию имеющегося p-ичного числа.
        /// </summary>
        /// <param name="object1">P-ичное число.</param>
        public PNumber(PNumber object1) {
            _value = object1._value;
            _basis = object1._basis;
        }

        /// <summary>
        /// Получает или задаёт внутреннее значение p-ичного числа.
        /// </summary>
        public string Value {
            get { return _value; }
            set { value = value.ToUpper(); if (Parse(value, _basis)) _value = value; }
        }
        /// <summary>
        /// Возвращает значение числа в системе счисления по умолчанию.
        /// </summary>
        public string DecimalValue { get { return ToString(); } }
        /// <summary>
        /// Получает или задаёт значение числа как численного типа.
        /// </summary>
        public double NumberValue {
            get { string a = ToString(); return a != "" ? double.Parse(a, _style, _format) : 0; }
            set { _value = Converter.ToString(value); }
        }

        /// <summary>
        /// Возвращает значение основания системы счисления p-ичного числа.
        /// </summary>
        public byte Basis { get { return _basis; } }

        /// <summary>
        /// Осуществляет проверку, является ли заданная строка p-ичным числом в указанной системе счисления.
        /// </summary>
        /// <param name="number">Строка, содержащая число.</param>
        /// <param name="basis">Основание системы счисления.</param>
        /// <returns>true, если строка является p-ичным числом; иначе false.</returns>
        public static bool Parse(string number, int basis = DecimalBasis) {
            bool hasDot = false;
            if (number.Length == 0) return true;
            if (number[0] == '-') number = number.Substring(1);
            foreach (var c in number) {
                // TODO: refactor DecimalPoint
                if (Converter.DigitOfChar(c) >= basis) {
                    if (c == DecimalPoint[0] && !hasDot) hasDot = true;
                    else return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Конвертирует внутреннее представление числа в указанную систему счисления.
        /// </summary>
        /// <param name="basis">Основание системы счисления.</param>
        public void Convert(byte basis) {
            _value = DoConversion(_value, _basis, basis);
            if(_value == "0") _value = string.Empty;
            _basis = basis;
        }

        /// <summary>
        /// Возвращает соответствующее p-ичному числу в указанной системе счисления строковое представление.
        /// </summary>
        /// <param name="basis">Основание системы счисления.</param>
        /// <param name="strict">true, если нужно сохранить незначащие символы.</param>
        /// <returns>Строка, содержащая число.</returns>
        public string ToString(byte basis = DecimalBasis, bool strict = false) {
            return DoConversion(_value, _basis, basis, strict);
        }

        /// <summary>
        /// Выполняет сложение двух p-ичных чисел.
        /// </summary>
        /// <param name="v1">Первый операнд.</param>
        /// <param name="v2">Второй операнд.</param>
        /// <returns>Результат операции.</returns>
        public static PNumber operator +(PNumber v1, PNumber v2) {
            return new PNumber(v1.NumberValue + v2.NumberValue, v1._basis);
        }

        /// <summary>
        /// Выполняет вычитание второго p-ичного числа из первого.
        /// </summary>
        /// <param name="v1">Первый операнд.</param>
        /// <param name="v2">Второй операнд.</param>
        /// <returns>Результат операции.</returns>
        public static PNumber operator -(PNumber v1, PNumber v2) {
            // TODO: use "+" with alt sign
            return new PNumber(v1.NumberValue - v2.NumberValue, v1._basis);
        }

        /// <summary>
        /// Выполняет умножение двух p-ичных чисел.
        /// </summary>
        /// <param name="v1">Первый операнд.</param>
        /// <param name="v2">Второй операнд.</param>
        /// <returns>Результат операции.</returns>
        public static PNumber operator *(PNumber v1, PNumber v2) {
            return new PNumber(v1.NumberValue * v2.NumberValue, v1._basis);
        }

        /// <summary>
        /// Выполняет деление первого p-ичного числа на второе.
        /// </summary>
        /// <param name="v1">Первый операнд.</param>
        /// <param name="v2">Второй операнд.</param>
        /// <returns>Результат операции.</returns>
        public static PNumber operator /(PNumber v1, PNumber v2) {
            return new PNumber(v1.NumberValue / v2.NumberValue, v1._basis);
        }

        /// <summary>
        /// Устанавливает значение числа равным 0.
        /// </summary>
        public void Reset() {
            _value = string.Empty;
        }

        /// <summary>
        /// Осуществляет конвертирование числа, записанного в одной системе счисления, в другую систему счисления.
        /// </summary>
        /// <param name="str">Строка, содержащая число.</param>
        /// <param name="p1">Основание исходной системы счисления.</param>
        /// <param name="p2">Основание желаемой системы счисления.</param>
        /// <param name="strict">true, если нужно сохранить все незначащие символы.</param>
        /// <returns></returns>
        public static string DoConversion(string str, byte p1, byte p2, bool strict = false) {
            var isNegative = false;
            if (str.Length == 0) return "0";
            //if(!double.TryParse(str, out v1)) // TODO: check for validity
            if(str[0] == '-') { // проверка на знак
                str = str.Substring(1); // отрезать первый символ
                isNegative = true;
            }

            // конвертация двумя проходами
            if (p1 != DecimalBasis) str = CP10.Convert(str, p1, strict);
            if (p2 != DecimalBasis) str = C10P.Convert(str, p2, strict);

            // вывод результата
            if (isNegative) str = '-' + str;
            return str;
        }
    }
}