﻿namespace proj2_tds_self {
    public static class Control {
        public static byte Basis {
            get { return Calc.Basis; }
            set { Calc.Basis = value; }
        }

        public static string Text { get { return Calc.Text; } }
        public static bool HasMemory { get { return Calc.MemoryNum.Value != ""; } }

        public static void ClearHistory() {
            History.EraseHistory();
        }

        public static void AddDigit(byte value) {
            Calc.AppendDigit(Converter.CharOfDigit(value));
        }

        /// <summary>
        /// Добавляет разделитель целой и дробной части в число.
        /// </summary>
        public static void AddDot() {
            Calc.AddDot();
        }

        public static void AddBinaryOperation(byte value) {
            switch (value) {
                case 0: AddBinaryOperation('+'); break;
                case 1: AddBinaryOperation('-'); break;
                case 2: AddBinaryOperation('*'); break;
                case 3: AddBinaryOperation('/'); break;
            }
        }

        public static void AddBinaryOperation(char value) {
            //if (Calc.FirstNum.Value.Length == 0) return;
            Calc.AddBinaryOperation(value);
        }

        public static void DoUnaryOperation(byte value) {
            switch (value) {
                case 21: Calc.ChangeSign(); break; // change sign
                case 22: Calc.Equality(); break; // equality
                case 23: Calc.Sqr(); break; // x^2
                case 24: Calc.Invert(); break; // 1/x
            }
        }

        public static void Clear() {
            Calc.Reset();
        }

        public static void ClearCurrent() {
            Calc.ResetCurrent(); // TODO
        }

        public static void Backspace() {
            Calc.Backspace();
        }

        public static void Paste(string p) { // TODO
            Calc.Paste(p);
        }

        // 0-15 числа 16-19 операции 20-22 спец операции 23-26 память 27 28 удаление
        public static void DoCommand(int tag) {
#if DEBUG
            Program.Log.WriteLine("Begin action {0}, state text: '{1}'", tag, Calc.Text);
#endif
            switch (tag) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                case 14:
                case 15: AddDigit((byte)tag); break;

                case 16: // '+'
                case 17: // '-'
                case 18: // '*'
                case 19: /* '/' */ AddBinaryOperation((byte)(tag - 16)); break;

                case 20: AddDot(); break;
                case 21: // change sign
                case 22: // equality
                case 23: // sqr
                case 24: DoUnaryOperation((byte)tag); break; // 1/x
                case 25: ClearCurrent(); break;
                case 26: Calc.MemoryPlus(); break;
                case 27: Calc.MemorySet(); break;
                case 28: Calc.MemoryRead(); break;
                case 29: Calc.MemoryClear(); break;
                case 30: Clear(); break;
                case 31: Backspace(); break;
                case 32: Calc.MemoryMinus(); break;
            }
#if DEBUG
            Program.Log.Write(Calc.State());
            Program.Log.WriteLine("Done action {0}, state text: '{1}'", tag, Calc.Text);
#endif
        }
    }
}