﻿namespace proj2_tds_self {
    internal class HistoryItem {
        private static int _numNext = 1;
        public readonly int Num;
        public readonly string First;
        public readonly string Second;
        public readonly string Operation;
        public readonly string Result;

        public HistoryItem(string first, string second, string operation, string result) {
            Num = _numNext++;
            First = first;
            Second = second;
            Operation = operation;
            Result = result;
        }
    }
}
