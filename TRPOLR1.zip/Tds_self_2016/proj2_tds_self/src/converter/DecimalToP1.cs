﻿using System;

namespace proj2_tds_self {
    /// <summary>
    /// Расширение конвертера для преобразования чисел из 10-чной системы в указанную.
    /// </summary>
    internal class DecimalToP1 : Converter {
        protected override string ConvertIntegerPart(string number, byte basis) { // OK
            ulong i = ulong.Parse(number);
            string integerPart = string.Empty;
            do {
                integerPart = CharOfDigit((byte)(i % basis)) + integerPart; // prepend
                i /= basis;
            } while (i > 0);
            return integerPart;
        }

        protected override string ConvertFractionPart(string number, byte basis) { // thx to B. Solovyov
            double f = double.Parse('0' + PNumber.DecimalPoint + number);
            string fractionPart = string.Empty;
            for (int i = 0; i < Accuracy && f > 0; i++) {
                f *= basis;
                byte digit = (byte)Math.Truncate(f);
                f -= digit;
                fractionPart += CharOfDigit(digit);
            }
            return fractionPart;
        }
    }
}