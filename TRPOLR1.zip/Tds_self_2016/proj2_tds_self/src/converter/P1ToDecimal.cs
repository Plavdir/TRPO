﻿namespace proj2_tds_self {
    /// <summary>
    /// Расширение конвертера для преобразования чисел из указанной системы в 10-чную.
    /// </summary>
    internal class P1ToDecimal : Converter {
        protected override string ConvertIntegerPart(string number, byte basis) // OK
        {
            ulong sum = 0, pr = 1;
            for (int i = number.Length - 1; i >= 0; i--, pr *= basis)
                sum += DigitOfChar(number[i]) * pr;
            return sum.ToString();
        }

        protected override string ConvertFractionPart(string number, byte basis) // OK
        {
            double sum = 0, pr = 1.0/basis;
            for (int i = 0; i < number.Length; i++, pr /= basis)
                sum += DigitOfChar(number[i]) * pr;
            return sum > 0 ? ToString(sum).Substring(2) : ""; // cut "0," at the beginning
        }
    }
}