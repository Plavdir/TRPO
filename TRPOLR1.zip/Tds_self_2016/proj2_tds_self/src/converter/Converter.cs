﻿using System;

namespace proj2_tds_self {
    /// <summary>
    /// Представляет обобщённый интерфейс конвертера.
    /// </summary>
    public abstract class Converter // : IConverter
    {
        /// <summary>
        /// Точность вычисления чисел с плавающей запятой.
        /// </summary>
        public const int Accuracy = 14;
        //public const string FormatString = "{0:F20}";
        /*private const string DoubleFixedPoint = 
            "0.###############################################################" +
            "#################################################################" +
            "#################################################################" +
            "#################################################################" +
            "#################################################################" +
            "################"; by stackoverflow */

        private static readonly string DoubleFixedPoint = "0." + new string('#', Accuracy);

        /// <summary>
        /// Преобразует число в строковое представление с учётом формата вывода.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToString(double value) {
            string ret = value.ToString(DoubleFixedPoint);
            if (ret.Contains(PNumber.DecimalPoint)) ret = ret.TrimEnd('0');
            return ret;
        }

        /// <summary>
        /// Конвертация числа. Направление конвертирования зависит от дочернего типа.
        /// </summary>
        /// <param name="number">Строка, содержащая число.</param>
        /// <param name="basis">Основание системы счисления, отличной от 10.</param>
        /// <param name="strict"></param>
        /// <returns></returns>
        public string Convert(string number, byte basis, bool strict = false) {
            string integer, fraction;
            SplitParts(number, out integer, out fraction); // выделение дробной и целой части числа

            string convertedNumber = ConvertIntegerPart(integer, basis); // конвертация для целой части

            if (!string.IsNullOrEmpty(fraction) || strict) { // если есть дробная часть то её конвертация
                if(number.Contains(PNumber.DecimalPoint)) convertedNumber += PNumber.DecimalPoint;
                if (!string.IsNullOrEmpty(fraction)) convertedNumber += ConvertFractionPart(fraction, basis);
            }
#if DEBUG
            //Program.log.WriteLine("Number = '{0}', basis {1}, result = '{2}'", number, basis, convertedNumber);
#endif
            return convertedNumber;
        }

        /// <summary>
        /// Выделение дробной и целой части из исходного числа.
        /// </summary>
        /// <param name="number"></param>
        /// <param name="integer"></param>
        /// <param name="fraction"></param>
        private static void SplitParts(string number, out string integer, out string fraction) {
            string[] ret = number.Split(PNumber.DecimalPoint.ToCharArray(), 2, StringSplitOptions.None);
            integer = ret[0];
            fraction = (ret.Length > 1 ? ret[1] : string.Empty);
        }

        /// <summary>
        /// Конвертация целой части числа.
        /// </summary>
        /// <param name="number">Число в строковом формате.</param>
        /// <param name="basis">Основание системы.</param>
        /// <returns>Результат конвертации.</returns>
        protected abstract string ConvertIntegerPart(string number, byte basis);

        /// <summary>
        /// Конвертация дробной части числа.
        /// </summary>
        /// <param name="number">Число в строковом формате.</param>
        /// <param name="basis">Основание системы.</param>
        /// <returns>Результат конвертации/</returns>
        protected abstract string ConvertFractionPart(string number, byte basis);

        /// <summary>
        /// Возвращает десятичное значение цифры в какой-либо другой системе счисления.
        /// </summary>
        /// <param name="c">Символ цифры.</param>
        /// <returns>Значение цифры.</returns>
        public static byte DigitOfChar(char c) {
            if (c >= '0' && c <= '9') return (byte) (c - '0');
            if (c >= 'A' && c <= 'F') return (byte) (c - 'A' + 10);
            if (c >= 'a' && c <= 'f') return (byte) (c - 'a' + 10);
            return byte.MaxValue;
        }

        /// <summary>
        /// Возвращает цифру по её десятичному значению.
        /// </summary>
        /// <param name="digit"></param>
        /// <returns></returns>
        public static char CharOfDigit(byte digit) {
            if (digit < 10)
                return (char)(digit + '0');
            return (char) (digit - 10 + 'A');
        }
    }
}