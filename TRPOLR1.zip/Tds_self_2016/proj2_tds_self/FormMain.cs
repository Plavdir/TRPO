﻿using System;
using System.Windows.Forms;

namespace proj2_tds_self {
    public partial class FormMain : Form {
        /// <summary>
        /// Главная форма приложения.
        /// </summary>
        public FormMain() {
            InitializeComponent();
        }

        private void RefreshText() { // TODO: implement bindable property on Calc.Text
            textBox1.Text = Control.Text;
            button9.Enabled = button10.Enabled = Control.HasMemory;
            foreach (var control in Controls) {
                if (control.GetType() == typeof(Button)) {
                    int value = Convert.ToInt32(((Button) control).Tag);
                    if (value >= PNumber.MaxBasis) continue;
                    ((Button)control).Enabled = value < Control.Basis;
                }
            }
        }

        private void HandleButtonPress(object sender, EventArgs e) {
            Control.DoCommand(int.Parse(((Button)sender).Tag.ToString()));
            RefreshText();
        }

        private void ChangeBasis(object sender, EventArgs e) {
            label1.Text = "Система счисления: " + trackBar1.Value;
            Control.Basis = ((byte)trackBar1.Value);
            RefreshText();
        }

        private void ShowHelpMbox(object sender, EventArgs e) {
            MessageBox.Show("0-1, A-F \t- ввод цифр\n" +
                            "+, -, *, / \t- соответствующие действия\n" +
                            ", или . \t- точка\n" +
                            "Стрелки \t- смена системы счисления", "Справка");
        }

        private void ShowAboutMbox(object sender, EventArgs e) {
            MessageBox.Show("Самодельное устройство для выполнения арифметических операций.\n\n" +
                            "Разработано рабоче-крестьянским сообществом во времена НЭПа.", "О программе");
        }

        private void AppExit(object sender, EventArgs e) {
            Application.Exit();
        }

        private void ShowHistoryForm(object sender, EventArgs e) {
            Program.HistoryForm.ShowDialog();
        }

        private void ClearHistory(object sender, EventArgs e) {
            Control.ClearHistory();
        }

        private void BeforeKeyPressed(object sender, KeyEventArgs e) { // при нажатии клавиши
            e.Handled = true;
            switch (e.KeyCode) {
                case Keys.Enter: Control.DoUnaryOperation(22); break; // TODO: handle
                case Keys.Back: Control.Backspace(); break;
                case Keys.Delete: Control.Clear(); break;
                case Keys.Left: {
                    if (trackBar1.Value > PNumber.MinBasis) {
                        trackBar1.Value--;
                        label1.Text = "Система счисления: " + trackBar1.Value;
                        Control.Basis = ((byte) trackBar1.Value);
                    }
                }
                break;
                case Keys.Right: {
                    if (trackBar1.Value < PNumber.MaxBasis) {
                        trackBar1.Value++;
                        label1.Text = "Система счисления: " + trackBar1.Value;
                        Control.Basis = ((byte) trackBar1.Value);
                    }
                }
                break;
                default: e.Handled = false; break;
            }
            RefreshText();
        }

        private void KeyPressed(object sender, KeyPressEventArgs e)
        {
            if (Converter.DigitOfChar(e.KeyChar) < Control.Basis) {
                Control.AddDigit(Converter.DigitOfChar(e.KeyChar));
                RefreshText();
                e.Handled = true;
                return;
            }
            e.Handled = true;
            switch(e.KeyChar) {
                case '+':
                case '-':
                case '*':
                case '/': Control.AddBinaryOperation(e.KeyChar); break;

                // небольшой костыль, thx to B. Solovyov
                case '.':
                case ',': Control.AddDot(); break;

                default: e.Handled = false; break;
            }
            RefreshText();
        }

        private void CopyToClipboard(object sender, EventArgs e) {
            Clipboard.SetText(Control.Text);
        }

        private void PasteFromClipboard(object sender, EventArgs e) {
            Control.Paste(Clipboard.GetText());
            RefreshText();
        }

        private void FormMain_Load(object sender, EventArgs e) {
            RefreshText();
        }
    }
}