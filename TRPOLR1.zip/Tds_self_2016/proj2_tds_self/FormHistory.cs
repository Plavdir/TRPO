﻿using System;
using System.Windows.Forms;

namespace proj2_tds_self
{
    /// <summary>
    /// Класс, представляющий форму с историей.
    /// </summary>
    public partial class FormHistory : Form
    {
        public FormHistory()
        {
            InitializeComponent();
            dataGridView1.Columns.Add("1", "# записи");
            dataGridView1.Columns.Add("2", "Первое число");
            dataGridView1.Columns.Add("3", "Операция");
            dataGridView1.Columns.Add("4", "Второе число");
            dataGridView1.Columns.Add("5", "Результат");
            this.UpdateTable();
        }

        private void DoCleanHistory(object sender, EventArgs e) // очищение истории
        {
            History.EraseHistory(); // очистка файла с историей
            while (dataGridView1.Rows.Count > 0) // очистка таблицы 
                dataGridView1.Rows.Remove(dataGridView1.Rows[dataGridView1.Rows.Count - 1]);
            this.UpdateTable(); // показать таблицу
        }

        public void UpdateTable() // показать таблицу
        {
            label1.Visible = !History.FillData(dataGridView1);
            //dataGridView1.Invalidate();
        }

        private void CloseWindow(object sender, EventArgs e) // закрыть историю
        {
            this.Close();
        }

        private void FormHistory_Load(object sender, EventArgs e)
        {
            this.UpdateTable();
        }
    }
}
