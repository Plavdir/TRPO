﻿using System;

namespace rgz_tds_self {
    // ReSharper disable once InconsistentNaming
    public class TMember {
        private int _degree;
        private double _coeff;

        public TMember(double coeff, int degree) {
            _degree = degree;
            _coeff = coeff;
        }

        public TMember() {
            _degree = 0;
            _coeff = 0;
        }

        public int GetDegree() {
            return _degree;
        }

        public double GetCoeff() {
            return _coeff;
        }

        public void SetDegree(int d) {
            _degree = d;
        }

        public void SetCoeff(double c) {
            _coeff = c;
        }

        public bool Equal(TMember extra) {
            return _coeff.Equals(extra._coeff) && (_degree == extra._degree);
        }

        public TMember Differetiate() {
            return new TMember(_coeff * _degree, _degree - 1);
        }

        public double Value(double x) {
            return _coeff * Math.Pow(x, _degree);
        }

        public override string ToString() {
            return _coeff + "*X^" + _degree;
        }

        public static bool operator >(TMember p, TMember q) {
            return (p._degree > q._degree);
        }

        public static bool operator <(TMember p, TMember q) {
            return (p._degree < q._degree);
        }

        public static TMember operator *(TMember p, TMember q) {
            return new TMember(p.GetCoeff() * q.GetCoeff(), p.GetDegree() + q.GetDegree());
        }
    }
}