﻿using System;

namespace rgz_tds_self {
    static class Program {
        [STAThread]
        static void Main(string[] args) {
            TPoly p1 = new TPoly(1, 0);
            TPoly p2 = new TPoly(2, 2);
            TPoly p3 = new TPoly(1, 1);
            TPoly p4 = new TPoly(1, 2);
            p1 += p2;
            //Q += R;
            //P *= Q;
            Console.WriteLine(p1);
            Console.WriteLine("Для продолжения нажмите любую клавишу...");
            Console.ReadKey();
        }
    }
}