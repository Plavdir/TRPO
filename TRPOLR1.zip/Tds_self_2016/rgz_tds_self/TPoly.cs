﻿using System;
using System.Collections.Generic;
#pragma warning disable 660,661

namespace rgz_tds_self {
    // ReSharper disable once InconsistentNaming
    public class TPoly {
        private List<TMember> Polynom = new List<TMember>();

        public TPoly(double coeff, int degree) {
            Polynom.Add(new TMember(coeff, degree));
        }

        public TPoly() {
            Polynom.Add(new TMember(0, 0));
        }

        public TMember this[int index] {
            get { return Polynom[index]; }
            set { Polynom[index] = value; }
        }

        public static bool operator ==(TPoly p, TPoly q) {
            if (p == null || q == null)
                return p == null && q == null;
            int n = p.Polynom.Count;
            if (q.Polynom.Count != n)
                return false;
            for (int i = 0; i < n; i++) {
                if (!(p.Polynom[i].GetCoeff().Equals(q.Polynom[i].GetCoeff())
                      && (p.Polynom[i].GetDegree() == q.Polynom[i].GetDegree())))
                    return false;
            }
            return true;
        }

        public static bool operator !=(TPoly p, TPoly q) {
            return !(p == q);
        }

        public static TPoly operator +(TPoly p, TPoly q) {
            return Primitive(p, q, '+');
        }

        public static TPoly operator -(TPoly p, TPoly q) {
            return Primitive(p, q, '-');
        }

        public static TPoly operator *(TPoly p, TPoly q) {
            TPoly a = new TPoly();
            a.Polynom.Clear();
            for (int i = 0; i < p.Polynom.Count; i++) {
                for (int j = 0; j < q.Polynom.Count; j++) {
                    a.Polynom.Add(p.Polynom[i] * q.Polynom[j]);
                }
            }
            int max = 0;
            bool f = false;
            TMember buf = new TMember();
            for (int i = 0; i < a.Polynom.Count; i++) {
                for (int j = i; j < a.Polynom.Count; j++) {
                    if (a.Polynom[j].GetDegree() > a.Polynom[max].GetDegree()) {
                        max = j;
                        f = true;
                    }
                }
                if (f) {
                    buf.SetDegree(a.Polynom[i].GetDegree());
                    buf.SetCoeff(a.Polynom[i].GetCoeff());
                    a.Polynom[i].SetDegree(a.Polynom[max].GetDegree());
                    a.Polynom[i].SetCoeff(a.Polynom[max].GetCoeff());
                    a.Polynom[max].SetDegree(buf.GetDegree());
                    a.Polynom[max].SetCoeff(buf.GetCoeff());
                }
            }
            for (int i = 0; i < a.Polynom.Count; i++) {
                for (int j = i + 1; j < a.Polynom.Count; j++) {
                    if (a.Polynom[i].GetDegree() != a.Polynom[j].GetDegree()) {
                        if (i == j)
                            a.Polynom.RemoveRange(i + 1, j - 1);
                        break;
                    }
                    a.Polynom[i].SetCoeff(a.Polynom[i].GetCoeff() + a.Polynom[j].GetCoeff());
                }
            }
            return a;
        }

        public override string ToString() {
            string answer = "";
            foreach (var y in Polynom) {
                string piece = y.ToString();
                if (piece[0] == '-')
                    answer += piece;
                else
                    answer += '+' + piece;
            }
            if (answer[0] == '+')
                answer = answer.Substring(1, answer.Length - 1);
            return answer;
        }

        public int GetDegree() {
            return Polynom[0].GetDegree();
        }

        public double GetCoeff(int x) {
            var y = Polynom.Find(z => z.GetDegree() == x);
            if (y == null)
                return 0;
            return y.GetCoeff();
        }

        public void ClearIt() {
            Polynom.Clear();
            Polynom.Add(new TMember());
        }

        private static TPoly Primitive(TPoly p, TPoly q, char s) {
            TPoly a = new TPoly();
            a.Polynom.Clear();
            a.Polynom.AddRange(q.Polynom);
            if (s == '-') a.Invert();
            a.Polynom.AddRange(p.Polynom);
            for (int i = a.Polynom.Count - 1; i >= p.Polynom.Count; i--) {
                var y = a.Polynom.FindIndex(z => z.GetDegree() == a.Polynom[i].GetDegree());
                if (y == i)
                    continue;
                a.Polynom[y].SetCoeff(a.Polynom[y].GetCoeff() + a.Polynom[i].GetCoeff());
                a.Polynom.RemoveAt(i);
                if (a.Polynom[y].GetCoeff().Equals(0) && a.Polynom.Count > 1) {
                    a.Polynom.RemoveAt(y);
                    i--;
                }
            }
            if (a.Polynom.Count != 1)
                a.Polynom.RemoveAll(x => x.GetCoeff().Equals(0));
            int max = 0;
            bool f = false;
            TMember buf = new TMember();
            for (int i = 0; i < a.Polynom.Count; i++) {
                for (int j = i; j < a.Polynom.Count; j++)
                    if (a.Polynom[j].GetDegree() > a.Polynom[max].GetDegree()) {
                        max = j;
                        f = true;
                    }
                if (f) {
                    buf.SetDegree(a.Polynom[i].GetDegree());
                    buf.SetCoeff(a.Polynom[i].GetCoeff());
                    a.Polynom[i].SetDegree(a.Polynom[max].GetDegree());
                    a.Polynom[i].SetCoeff(a.Polynom[max].GetCoeff());
                    a.Polynom[max].SetDegree(buf.GetDegree());
                    a.Polynom[max].SetCoeff(buf.GetCoeff());
                }
            }
            return a;
        }

        public double Count(double x) {
            double answer = 0;
            foreach (var a in Polynom)
                answer += a.GetCoeff() * Math.Pow(x, a.GetDegree());
            return answer;
        }

        public void Invert() {
            foreach (var a in Polynom)
                a.SetCoeff(a.GetCoeff() * -1);
        }

        public TPoly Differentiate() {
            TPoly answer = new TPoly();
            answer.Polynom.AddRange(Polynom);
            foreach (var a in answer.Polynom) {
                a.SetCoeff(a.GetCoeff() * a.GetDegree());
                a.SetDegree(a.GetDegree() - 1);
            }
            answer.Polynom.RemoveAll(z => z.GetDegree() < 0);
            return answer;
        }
    }
}