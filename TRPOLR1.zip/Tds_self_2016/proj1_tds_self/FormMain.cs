﻿using System;
using System.Windows.Forms;

namespace proj1_tds_self
{
    public partial class FormMain : Form
    {
        /// <summary>
        /// Флаг, определяющий, содержит ли число десятичную точку.
        /// </summary>
        protected bool has_dot = false;
        /// <summary>
        /// Текущие основания систем счисления. Обновляются вместе с действиями на форме, так что ничего страшного.
        /// </summary>
        protected byte p1 = 2, p2 = 10;

        internal Editor editor = new Editor();
        protected History history = Program.HistoryObject;

        /// <summary>
        /// Конструктор. Начальная загрузка визуальных компонентов.
        /// </summary>
        public FormMain()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0; // value for 2
            comboBox2.SelectedIndex = 8; // value for 10
            textBox1.Text = "";
            textBox2.Text = "";
        }

        /// <summary>
        /// Выбор основания исходного числа, а также блокировка/разблокировка соответствующих кнопок интерфейса.
        /// </summary>
        /// <param name="sender">Не используется.</param>
        /// <param name="e">Не используется.</param>
        public void ChangeSourceBasis(object sender, EventArgs e)
        {
            this.p1 = Byte.Parse(comboBox1.Text);

            button_2.Enabled = false;
            button_3.Enabled = false;
            button_4.Enabled = false;
            button_5.Enabled = false;
            button_6.Enabled = false;
            button_7.Enabled = false;
            button_8.Enabled = false;
            button_9.Enabled = false;
            button_A.Enabled = false;
            button_B.Enabled = false;
            button_C.Enabled = false;
            button_D.Enabled = false;
            button_E.Enabled = false;
            button_F.Enabled = false;

            if (p1 > 2)
                button_2.Enabled = true;
            if (p1 > 3)
                button_3.Enabled = true;
            if (p1 > 4)
                button_4.Enabled = true;
            if (p1 > 5)
                button_5.Enabled = true;
            if (p1 > 6)
                button_6.Enabled = true;
            if (p1 > 7)
                button_7.Enabled = true;
            if (p1 > 8)
                button_8.Enabled = true;
            if (p1 > 9)
                button_9.Enabled = true;
            if (p1 > 10)
                button_A.Enabled = true;
            if (p1 > 11)
                button_B.Enabled = true;
            if (p1 > 12)
                button_C.Enabled = true;
            if (p1 > 13)
                button_D.Enabled = true;
            if (p1 > 14)
                button_E.Enabled = true;
            if (p1 > 15)
                button_F.Enabled = true;

            DoClean(null, null); // небольшой костыль
        }

        private void ChangeDestinBasis(object sender, EventArgs e)
        {
            p2 = Byte.Parse(comboBox2.Text);
        }

        public void AddDigit(object sender, EventArgs e) // обработка нажатия цифровых клавиш интерфейса
        {
            Button button = (Button)sender;
            // проверка, которая запрещает ставить ноль первым в число
            if (button.Text != "0" || !textBox1.Text.Equals(String.Empty)) 
                textBox1.Text += button.Text;

            // this breaks history
            //this.DoConversion(null, null); // WARNING: костыль
        }

        private void AddDot(object sender, EventArgs e)  // точка
        {
            if (textBox1.Text == "")
                textBox1.Text += "0";
            if (!has_dot)
            {
                textBox1.Text += Program.DecimalPoint;
                has_dot = true;
            }
        }

        private void ChangeSign(object sender, EventArgs e) // +-
        {
            string str = textBox1.Text;
            if (textBox1.Text != "")
            {
                if (textBox1.Text[0] == '-')
                    textBox1.Text = textBox1.Text.Substring(1, textBox1.Text.Length - 1);
                else
                    textBox1.Text = "-" + str;
            }
        }

        private void DoBackspace(object sender, EventArgs e) // backspace
        {
            if (textBox1.Text[textBox1.Text.Length - 1] == Program.DecimalPoint[0])
                has_dot = false;
            textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
            if (textBox1.Text == "-")
                textBox1.Text = "";
        }

        private void DoClean(object sender, EventArgs e) // очистка
        {
            has_dot = false;
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e) // изменение исходного числа
        {
            textBox1.Text = editor.DoEditing(textBox1.Text, p1);
            textBox1.SelectionStart = textBox1.Text.Length; // установить курсор в конце строки
        }

        private void DoConversion(object sender, EventArgs ev) // преобразование
        {
            byte p1, p2;
            try
            {
                if (!Byte.TryParse(comboBox1.Text, out p1))
                    throw new Exception("Основание исходной системы счисления введено неверно.");
                if (!Byte.TryParse(comboBox2.Text, out p2))
                    throw new Exception("Основание желаемой системы счисления введено неверно.");
                if (textBox1.Text == "")
                    throw new Exception("Пожалуйста, введите исходное число для конвертации.");

                // если последний элемент строки точка, то поставить ноль
                if (textBox1.Text[textBox1.Text.Length - 1].ToString() == Program.DecimalPoint)
                    textBox1.Text += "0";

                textBox2.Text = Control.DoConversion(textBox1.Text, p1, p2);
                history.AddToHistory(textBox2.Text, p1, p2, textBox1.Text);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Ошибка при конвертации");
            }
        }

        private void ExitApplication(object sender, EventArgs e) // выход
        {
            Application.Exit();
        }

        private void ShowHelp(object sender, EventArgs e)  // вызов справки
        {
            Program.AboutForm.ShowDialog();
        }

        private void ShowHistory(object sender, EventArgs e) // вызов истории
        {
            Program.HistoryForm.ShowDialog();
        }

        private void ClearHistory(object sender, EventArgs e) // очищение истории
        {
            Program.HistoryObject.EraseHistory();
        }
    }


}
