﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace proj1_tds_self
{
    public class History
    {
        ArrayList history_list = new ArrayList();

        /// <summary>
        /// Создаёт новый объект списка истории, загружая данные из файла Program.HistoryFile.
        /// </summary>
        public History()
        {
            try // throws I/O exceptions 
            {
                foreach (string line in File.ReadAllLines(Program.HistoryFile, Encoding.UTF8))
                {
                    history_list.Add(line.Split(' '));
                }
            }
            catch
            {
                // TODO: workaround
                /*MessageBox.Show(
                "Не удалось обработать файл истории " + Program.HistoryFile +"\n"+ e.Message, 
                "Ошибка!");
                */
            }
        }

        /// <summary>
        /// Очищает список истории, как в памяти, так и в файле.
        /// </summary>
        public void EraseHistory()
        {
            history_list.Clear();
            FileInfo file = new FileInfo(Program.HistoryFile);
            if (file.Exists) // Если файл существует
                file.Delete(); // Удаляем
        }

        public void AddToHistory(string new_data, byte p1, byte p2, string old_data)
        {
            string date = DateTime.Now.ToShortDateString(); //получение даты
            string time = DateTime.Now.ToShortTimeString(); //получение времени
            string str = old_data + " " + p1.ToString() + " " + p2.ToString() + " " + new_data + " " + date + " " + time;
            history_list.Add(str);
        }

        /// <summary>
        /// Заполняет DataGridView данными из ArrayList.
        /// </summary>
        /// <param name="Data">Ссылка на компонент DataGridView.</param>
        /// <returns>false, если ArrayList пуст, иначе true.</returns>
        public bool FillData(DataGridView Data)
        {
            Data.Rows.Clear();
            if (history_list.Count > 0)
            {
                string[] A;
                int i = 0;
                foreach (string line in history_list)
                {
                    A = line.Split(' ');
                    Data.Rows.Add();
                    for (int j = 0; j < 6; j++) // загрузка данных в таблицу из 6 столбцов
                        Data[j, i].Value = A[j];
                    i++;
                }
                return true;
            }
            return false;
        }
    }
}
