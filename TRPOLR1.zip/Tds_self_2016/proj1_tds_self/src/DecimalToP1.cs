﻿using System;

namespace proj1_tds_self
{
    internal class DecimalToP1 : Converter
    {
        protected override string ConvertIntegerPart(string number, byte basis) // OK
        {
            UInt64 integer_part = UInt64.Parse(number);
            string ipcn = String.Empty;
            do {
                ipcn = CharOfDigit((byte)(integer_part % basis)) + ipcn; // prepend
                integer_part /= basis;
            }
            while (integer_part > 0);
            return ipcn;
        }

        protected override string ConvertFractionPart(string number, byte basis) // some magic here
        {
            double tmp;
            UInt64 tmp3;
            number = "0" + Program.DecimalPoint + number; // wow
            double fraction_part = double.Parse(number);
            //string number = fraction_part.ToString();
            string result = String.Empty;
            int k = ((number.Length) * 10) / basis;
            double kk = ((number.Length) * 10.0) / basis;
            if (kk > 0 && kk < 1)
                k = 1;
            while (k > 0)
            {
                tmp = fraction_part * basis;
                tmp3 = System.Convert.ToUInt64(tmp);
                if (tmp3 > tmp)
                    tmp3--;
                fraction_part = tmp - tmp3;
                result += CharOfDigit((byte)tmp3);
                k--;
            }
            while (result.Length > 0 && result[result.Length - 1] == '0')
                result = result.Substring(0, result.Length - 1);

            return result;
        }
    }
}
