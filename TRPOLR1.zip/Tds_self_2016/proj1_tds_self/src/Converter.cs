﻿using System;

namespace proj1_tds_self
{
    /*interface IConverter
    {
        public static string Convert(string number, byte basis);
        /// <summary>
        /// Разделение числа на целую часть и дробную.
        /// </summary>
        /// <param name="number">Подлежащее обработке число.</param>
        /// <param name="integer">Переменная для хранения целой части.</param>
        /// <param name="fraction">Переменная для хранения дробной части.</param>
        static void SplitParts(string number, out string integer, out string fraction);
        /// <summary>
        /// Преобразование целой части числа.
        /// </summary>
        /// <param name="number">Число в строковом формате.</param>
        /// <param name="basis">Основание исходной или целевой системы счисления, в зависимости от реализации.</param>
        /// <returns></returns>
        static string ConvertIntegerPart(string number, byte basis);
        static string ConvertFractionPart(string number, byte basis);
        static int FindPosition(char c);
    }*/

    abstract class Converter // : IConverter
    {
        /// <summary>
        /// Конвертация числа из р1 в десятичную систему
        /// </summary>
        /// <param name="number"></param>
        /// <param name="basis"></param>
        /// <returns></returns>
        public string Convert(string number, byte basis, int fract_digits = -1)
        {
            string integer, fraction;
            SplitParts(number, out integer, out fraction); // выделение дробной и целой части числа

            string converted_number = ConvertIntegerPart(integer, basis); // конвертация для целой части

            if (!String.IsNullOrEmpty(fraction)) // если есть дробная часть то конвертация для дробной части
                converted_number += Program.DecimalPoint + ConvertFractionPart(fraction, basis);

            return converted_number;
        }

        /// <summary>
        /// Выделение дробной и целой части из исходного числа.
        /// </summary>
        /// <param name="number"></param>
        /// <param name="integer"></param>
        /// <param name="fraction"></param>
        protected void SplitParts(string number, out string integer, out string fraction)
        {
            /*integer = "";
            int i = 0;
            // TODO: заменить костыль с DecimalPoint[0]
            while (i < number.Length && number[i] != Program.DecimalPoint[0]) // просматриваем до точки или конца числа
            {
                integer += number[i];
                i++;
            }
            int j = 10;
            i++;
            fraction = String.Empty;
            double fraction_part = (double)Decimal.Zero;
            // TODO: што за магия с "* / 10" ?!
            while (i < number.Length) // выделяем дробную часть
            {
                var xxx = FindPosition(number[i]);
                fraction_part += (xxx * 1.0) / j;
                j *= 10;
                i++;
            }
            if(!fraction_part.Equals(Decimal.Zero))
                fraction = fraction_part.ToString();*/
            string[] ret = number.Split(Program.DecimalPoint.ToCharArray(), 2, StringSplitOptions.None);
            integer = ret[0];
            fraction = (ret.Length > 1 ? ret[1] : String.Empty);
        }

        /// <summary>
        /// Конвертация целой части числа.
        /// </summary>
        /// <param name="number">Число в строковом формате.</param>
        /// <param name="basis">Основание системы.</param>
        /// <returns>Результат конвертации.</returns>
        abstract protected string ConvertIntegerPart(string number, byte basis);

        /// <summary>
        /// Конвертация дробной части числа.
        /// </summary>
        /// <param name="number">Число в строковом формате.</param>
        /// <param name="basis">Основание системы.</param>
        /// <returns>Результат конвертации/</returns>
        abstract protected string ConvertFractionPart(string number, byte basis);

        /// <summary>
        /// Возвращает десятичное значение цифры в какой-либо другой системе счисления.
        /// </summary>
        /// <param name="c">Символ цифры.</param>
        /// <returns>Значение цифры.</returns>
        protected byte DigitOfChar(char c)
        {
            if (c >= '0' && c <= '9')
                return (byte)(c - '0');
            if (c >= 'A' && c <= 'F')
                return (byte)(c - 'A' + 10);
            return 0; // will it help?
        }

        /// <summary>
        /// Возвращает цифру по её десятичному значению.
        /// </summary>
        /// <param name="digit"></param>
        /// <returns></returns>
        protected char CharOfDigit(byte digit)
        {
            if (digit < 10)
                return digit.ToString()[0];
            else
                return (char)(digit - 10 + 'A');
        }
    }
}
