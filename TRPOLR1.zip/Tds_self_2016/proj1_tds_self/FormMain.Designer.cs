﻿namespace proj1_tds_self
{
    partial class FormMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button_0 = new System.Windows.Forms.Button();
            this.button_1 = new System.Windows.Forms.Button();
            this.button_2 = new System.Windows.Forms.Button();
            this.button_3 = new System.Windows.Forms.Button();
            this.button_dot = new System.Windows.Forms.Button();
            this.button_4 = new System.Windows.Forms.Button();
            this.button_5 = new System.Windows.Forms.Button();
            this.button_6 = new System.Windows.Forms.Button();
            this.button_7 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button_8 = new System.Windows.Forms.Button();
            this.button_9 = new System.Windows.Forms.Button();
            this.button_A = new System.Windows.Forms.Button();
            this.button_B = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button_C = new System.Windows.Forms.Button();
            this.button_D = new System.Windows.Forms.Button();
            this.button_E = new System.Windows.Forms.Button();
            this.button_F = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.историяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.историяToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьИсториюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьИсториюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16"});
            this.comboBox1.Location = new System.Drawing.Point(24, 27);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(37, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ChangeSourceBasis);
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16"});
            this.comboBox2.Location = new System.Drawing.Point(24, 71);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(37, 21);
            this.comboBox2.TabIndex = 2;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.ChangeDestinBasis);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(80, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(254, 21);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(80, 71);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(254, 21);
            this.textBox2.TabIndex = 4;
            // 
            // button_0
            // 
            this.button_0.Location = new System.Drawing.Point(31, 226);
            this.button_0.Name = "button_0";
            this.button_0.Size = new System.Drawing.Size(37, 37);
            this.button_0.TabIndex = 5;
            this.button_0.Text = "0";
            this.button_0.UseVisualStyleBackColor = true;
            this.button_0.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_1
            // 
            this.button_1.Location = new System.Drawing.Point(67, 226);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(37, 37);
            this.button_1.TabIndex = 6;
            this.button_1.Text = "1";
            this.button_1.UseVisualStyleBackColor = true;
            this.button_1.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_2
            // 
            this.button_2.Enabled = false;
            this.button_2.Location = new System.Drawing.Point(103, 226);
            this.button_2.Name = "button_2";
            this.button_2.Size = new System.Drawing.Size(37, 37);
            this.button_2.TabIndex = 7;
            this.button_2.Text = "2";
            this.button_2.UseVisualStyleBackColor = true;
            this.button_2.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_3
            // 
            this.button_3.Enabled = false;
            this.button_3.Location = new System.Drawing.Point(139, 226);
            this.button_3.Name = "button_3";
            this.button_3.Size = new System.Drawing.Size(37, 37);
            this.button_3.TabIndex = 8;
            this.button_3.Text = "3";
            this.button_3.UseVisualStyleBackColor = true;
            this.button_3.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_dot
            // 
            this.button_dot.Location = new System.Drawing.Point(182, 226);
            this.button_dot.Name = "button_dot";
            this.button_dot.Size = new System.Drawing.Size(37, 37);
            this.button_dot.TabIndex = 9;
            this.button_dot.Text = ".";
            this.button_dot.UseVisualStyleBackColor = true;
            this.button_dot.Click += new System.EventHandler(this.AddDot);
            // 
            // button_4
            // 
            this.button_4.Enabled = false;
            this.button_4.Location = new System.Drawing.Point(31, 190);
            this.button_4.Name = "button_4";
            this.button_4.Size = new System.Drawing.Size(37, 37);
            this.button_4.TabIndex = 10;
            this.button_4.Text = "4";
            this.button_4.UseVisualStyleBackColor = true;
            this.button_4.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_5
            // 
            this.button_5.Enabled = false;
            this.button_5.Location = new System.Drawing.Point(67, 190);
            this.button_5.Name = "button_5";
            this.button_5.Size = new System.Drawing.Size(37, 37);
            this.button_5.TabIndex = 11;
            this.button_5.Text = "5";
            this.button_5.UseVisualStyleBackColor = true;
            this.button_5.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_6
            // 
            this.button_6.Enabled = false;
            this.button_6.Location = new System.Drawing.Point(103, 190);
            this.button_6.Name = "button_6";
            this.button_6.Size = new System.Drawing.Size(37, 37);
            this.button_6.TabIndex = 12;
            this.button_6.Text = "6";
            this.button_6.UseVisualStyleBackColor = true;
            this.button_6.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_7
            // 
            this.button_7.Enabled = false;
            this.button_7.Location = new System.Drawing.Point(139, 190);
            this.button_7.Name = "button_7";
            this.button_7.Size = new System.Drawing.Size(37, 37);
            this.button_7.TabIndex = 13;
            this.button_7.Text = "7";
            this.button_7.UseVisualStyleBackColor = true;
            this.button_7.Click += new System.EventHandler(this.AddDigit);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(182, 190);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(37, 37);
            this.button10.TabIndex = 14;
            this.button10.Text = "+/-";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.ChangeSign);
            // 
            // button_8
            // 
            this.button_8.Enabled = false;
            this.button_8.Location = new System.Drawing.Point(31, 154);
            this.button_8.Name = "button_8";
            this.button_8.Size = new System.Drawing.Size(37, 37);
            this.button_8.TabIndex = 15;
            this.button_8.Text = "8";
            this.button_8.UseVisualStyleBackColor = true;
            this.button_8.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_9
            // 
            this.button_9.Enabled = false;
            this.button_9.Location = new System.Drawing.Point(67, 154);
            this.button_9.Name = "button_9";
            this.button_9.Size = new System.Drawing.Size(37, 37);
            this.button_9.TabIndex = 16;
            this.button_9.Text = "9";
            this.button_9.UseVisualStyleBackColor = true;
            this.button_9.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_A
            // 
            this.button_A.Enabled = false;
            this.button_A.Location = new System.Drawing.Point(103, 154);
            this.button_A.Name = "button_A";
            this.button_A.Size = new System.Drawing.Size(37, 37);
            this.button_A.TabIndex = 17;
            this.button_A.Text = "A";
            this.button_A.UseVisualStyleBackColor = true;
            this.button_A.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_B
            // 
            this.button_B.Enabled = false;
            this.button_B.Location = new System.Drawing.Point(139, 154);
            this.button_B.Name = "button_B";
            this.button_B.Size = new System.Drawing.Size(37, 37);
            this.button_B.TabIndex = 18;
            this.button_B.Text = "B";
            this.button_B.UseVisualStyleBackColor = true;
            this.button_B.Click += new System.EventHandler(this.AddDigit);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(182, 154);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(37, 37);
            this.button15.TabIndex = 19;
            this.button15.Text = "BS";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.DoBackspace);
            // 
            // button_C
            // 
            this.button_C.Enabled = false;
            this.button_C.Location = new System.Drawing.Point(31, 118);
            this.button_C.Name = "button_C";
            this.button_C.Size = new System.Drawing.Size(37, 37);
            this.button_C.TabIndex = 20;
            this.button_C.Text = "C";
            this.button_C.UseVisualStyleBackColor = true;
            this.button_C.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_D
            // 
            this.button_D.Enabled = false;
            this.button_D.Location = new System.Drawing.Point(67, 118);
            this.button_D.Name = "button_D";
            this.button_D.Size = new System.Drawing.Size(37, 37);
            this.button_D.TabIndex = 21;
            this.button_D.Text = "D";
            this.button_D.UseVisualStyleBackColor = true;
            this.button_D.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_E
            // 
            this.button_E.Enabled = false;
            this.button_E.Location = new System.Drawing.Point(103, 118);
            this.button_E.Name = "button_E";
            this.button_E.Size = new System.Drawing.Size(37, 37);
            this.button_E.TabIndex = 22;
            this.button_E.Text = "E";
            this.button_E.UseVisualStyleBackColor = true;
            this.button_E.Click += new System.EventHandler(this.AddDigit);
            // 
            // button_F
            // 
            this.button_F.Enabled = false;
            this.button_F.Location = new System.Drawing.Point(139, 118);
            this.button_F.Name = "button_F";
            this.button_F.Size = new System.Drawing.Size(37, 37);
            this.button_F.TabIndex = 23;
            this.button_F.Text = "F";
            this.button_F.UseVisualStyleBackColor = true;
            this.button_F.Click += new System.EventHandler(this.AddDigit);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(182, 118);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(37, 37);
            this.button20.TabIndex = 24;
            this.button20.Text = "CE";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.DoClean);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button21.Location = new System.Drawing.Point(239, 158);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(95, 69);
            this.button21.TabIndex = 25;
            this.button21.Text = "Преобразовать";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.DoConversion);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.историяToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(117, 26);
            // 
            // историяToolStripMenuItem
            // 
            this.историяToolStripMenuItem.Name = "историяToolStripMenuItem";
            this.историяToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.историяToolStripMenuItem.Text = "История";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.историяToolStripMenuItem1,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(346, 24);
            this.menuStrip1.TabIndex = 27;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem1});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.ExitApplication);
            // 
            // историяToolStripMenuItem1
            // 
            this.историяToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьИсториюToolStripMenuItem,
            this.очиститьИсториюToolStripMenuItem});
            this.историяToolStripMenuItem1.Name = "историяToolStripMenuItem1";
            this.историяToolStripMenuItem1.Size = new System.Drawing.Size(61, 20);
            this.историяToolStripMenuItem1.Text = "История";
            // 
            // открытьИсториюToolStripMenuItem
            // 
            this.открытьИсториюToolStripMenuItem.Name = "открытьИсториюToolStripMenuItem";
            this.открытьИсториюToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.открытьИсториюToolStripMenuItem.Text = "Открыть историю";
            this.открытьИсториюToolStripMenuItem.Click += new System.EventHandler(this.ShowHistory);
            // 
            // очиститьИсториюToolStripMenuItem
            // 
            this.очиститьИсториюToolStripMenuItem.Name = "очиститьИсториюToolStripMenuItem";
            this.очиститьИсториюToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.очиститьИсториюToolStripMenuItem.Text = "Очистить историю";
            this.очиститьИсториюToolStripMenuItem.Click += new System.EventHandler(this.ClearHistory);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            this.справкаToolStripMenuItem.Click += new System.EventHandler(this.ShowHelp);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 295);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button_F);
            this.Controls.Add(this.button_E);
            this.Controls.Add(this.button_D);
            this.Controls.Add(this.button_C);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button_B);
            this.Controls.Add(this.button_A);
            this.Controls.Add(this.button_9);
            this.Controls.Add(this.button_8);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button_7);
            this.Controls.Add(this.button_6);
            this.Controls.Add(this.button_5);
            this.Controls.Add(this.button_4);
            this.Controls.Add(this.button_dot);
            this.Controls.Add(this.button_3);
            this.Controls.Add(this.button_2);
            this.Controls.Add(this.button_1);
            this.Controls.Add(this.button_0);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(362, 333);
            this.MinimumSize = new System.Drawing.Size(362, 333);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Конвертер";
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button_0;
        private System.Windows.Forms.Button button_1;
        private System.Windows.Forms.Button button_2;
        private System.Windows.Forms.Button button_3;
        private System.Windows.Forms.Button button_dot;
        private System.Windows.Forms.Button button_4;
        private System.Windows.Forms.Button button_5;
        private System.Windows.Forms.Button button_6;
        private System.Windows.Forms.Button button_7;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button_8;
        private System.Windows.Forms.Button button_9;
        private System.Windows.Forms.Button button_A;
        private System.Windows.Forms.Button button_B;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button_C;
        private System.Windows.Forms.Button button_D;
        private System.Windows.Forms.Button button_E;
        private System.Windows.Forms.Button button_F;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem историяToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem историяToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem открытьИсториюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem очиститьИсториюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;

    }
}

