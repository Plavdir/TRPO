﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace proj1_tds_self
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormMain());
        }

        // Управление дополнительными формами приложения
        private static FormAbout _aboutForm;
        private static FormHistory _historyForm;
        public static FormAbout AboutForm {
            get {
                if (_aboutForm == null) _aboutForm = new FormAbout();
                return _aboutForm;
            }
        }
        public static FormHistory HistoryForm {
            get {
                if (_historyForm == null) _historyForm = new FormHistory();
                return _historyForm;
            }
        }

        /// <summary>
        /// Текстовый файл для хранения списка истории.
        /// </summary>
        public static string HistoryFile { get { return "history.txt"; } }
        private static History _history;
        public static History HistoryObject {
            get {
                if (_history == null) _history = new History();
                return _history;
            }
        }

        public static string DecimalPoint { 
            get { return CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator; } 
        }
    }
}
