﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace proj2_tds_self
{
    class Complex
    {
        public Int64 Re;
        public Int64 Im;

        public Complex(Int64 _Re = 0, Int64 _Im = 0)
        {
            this.Re = _Re;
            this.Im = _Im;
        }

        public static Complex operator +(Complex a, Complex b)
        {
            return new Complex(a.Re + b.Re, a.Im + b.Im);
        }

        public static Complex operator -(Complex a, Complex b)
        {
            return new Complex(a.Re - b.Re, a.Im - b.Im);
        }

        public static Complex operator *(Complex a, Complex b)
        {
            Int64 re = a.Re * b.Re;
            Int64 im = a.Re * b.Im;
            im += a.Im * b.Re;
            re += a.Im * b.Im * (-1);
            return new Complex(re, im);
        }

        public static Complex operator /(Complex a, Complex b)
        {
            Complex up = a * new Complex(b.Re, -b.Im);
            Int64 down = b.Re * b.Re + b.Im * b.Im;
            return new Complex(up.Re / down, up.Im / down);
        }

        public override string ToString()
        {
            string ret = this.Re.ToString();
            if (this.Im != 0)
            {
                ret += ((this.Im > 0) ? "+" : "-");
                if (Math.Abs(this.Im) != 1) ret += Math.Abs(this.Im).ToString();
                ret += "i";
            }
            return ret;
        }
    }
}
