﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using proj2_tds_self;

namespace proj2_tds_self_test
{
    [TestClass]
    public class ConverterInterop
    {
        [TestMethod]
        public void TestConvert1() {
            string a = "0,00000000000000001";
            Assert.AreEqual(a, PNumber.DoConversion(a, 10, 10));
        }
    }
}
