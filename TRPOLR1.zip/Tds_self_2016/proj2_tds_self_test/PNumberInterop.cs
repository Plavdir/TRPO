﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using proj2_tds_self;

namespace proj2_tds_self_test
{
    [TestClass]
    public class PNumberInterop
    {
        [TestMethod]
        public void BasicMethod1() {
            var v1 = new PNumber("");
            Assert.AreEqual("", v1.Value);
        }

        [TestMethod]
        public void BasicMethod2()
        {
            var v1 = new PNumber("10");
            v1.Convert(16);
            Assert.AreEqual("A", v1.Value);
        }

        [TestMethod]
        public void BasicMethod3()
        {
            var v1 = new PNumber("");
            Assert.AreEqual("0", v1.DecimalValue);
        }

        [TestMethod]
        public void BasicMethod4()
        {
            var v1 = new PNumber("FF", 16);
            Assert.AreEqual("255", v1.DecimalValue);
        }

        [TestMethod]
        public void OperatorPlus1()
        {
            var v1 = new PNumber("3", 10);
            var v2 = new PNumber("7", 8);
            Assert.AreEqual("12", (v1 + v2).ToString(8));
        }

        [TestMethod]
        public void OperatorPlus2()
        {
            var v1 = new PNumber("3,5", 10);
            var v2 = new PNumber("4,4", 10);
            Assert.AreEqual("7,9", (v1 + v2).ToString(10));
        }

        [TestMethod]
        public void OperatorMul1()
        {
            var v1 = new PNumber("15", 10);
            var v2 = new PNumber("14", 10);
            Assert.AreEqual("210", (v1 * v2).ToString());
        }

        [TestMethod]
        public void Conversion1()
        {
            var v1 = new PNumber("37", 10);
            v1.Convert(2);
            Assert.AreEqual("100101", v1.Value);
        }

        [TestMethod]
        public void Conversion2()
        {
            var v1 = new PNumber("12,5", 10);
            v1.Convert(2);
            Assert.AreEqual("1100,1", v1.Value);
        }
    }
}
