﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace proj1_tds_self.UnitTests
{
    [TestClass]
    public class PublicConversion
    {
        [TestMethod]
        public void TestIfFIs15()
        {
            Assert.AreEqual("15", Control.DoConversion("F", 16, 10));
        }

        [TestMethod]
        public void TestIfMinusFIsMinus15()
        {
            Assert.AreEqual("-15", Control.DoConversion("-F", 16, 10));
        }

        [TestMethod]
        public void TestIf10Is1010()
        {
            Assert.AreEqual("1010", Control.DoConversion("10", 10, 2));
        }

        [TestMethod]
        public void TestIf33Is100001()
        {
            Assert.AreEqual("100001", Control.DoConversion("33", 10, 2));
        }

        [TestMethod]
        public void TestIfSeven1Is777()
        {
            Assert.AreEqual("777", Control.DoConversion("111111111", 2, 8));
        }

        [TestMethod]
        public void TestIfMinus323IsMinus3B()
        {
            Assert.AreEqual("-3B", Control.DoConversion("-323", 4, 16));
        }

        [TestMethod]
        public void Test32BitUInt()
        {
            Assert.AreEqual("4294967295", Control.DoConversion("FFFFFFFF", 16, 10));
        }

        [TestMethod]
        public void Test63BitUInt()
        {
            Assert.AreEqual("9223372036854775807", Control.DoConversion("7FFFFFFFFFFFFFFF", 16, 10));
        }

        [TestMethod]
        public void Test64BitUInt() // chess number! my fave somewhen..
        {
            Assert.AreEqual("18446744073709551615", Control.DoConversion("FFFFFFFFFFFFFFFF", 16, 10));
        }

        [TestMethod]
        public void TestFractionalNumber1()
        {
            Assert.AreEqual("0,1", Control.DoConversion("0,5", 10, 2));
        }

        [TestMethod]
        public void TestFractionalNumber1Rev()
        {
            Assert.AreEqual("0,5", Control.DoConversion("0,1", 2, 10));
        }

        [TestMethod]
        public void TestFractionalNumber2()
        {
            Assert.AreEqual("1,8", Control.DoConversion("1,5", 10, 16));
        }

        [TestMethod]
        public void TestFractionalNumber3()
        {
            Assert.AreEqual("11000,01111111111", Control.DoConversion("18,7FE", 16, 2));
        }

        [TestMethod]
        public void TestFractionalNumber4() // how many digits should we leave?
        {
            Assert.AreEqual("A,4CCC", Control.DoConversion("10,30000", 10, 16));
        }
    }
}
